/* Teensyduino Core Library
 * http://www.pjrc.com/teensy/
 * Copyright (c) 2017 PJRC.COM, LLC.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * 1. The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * 2. If the Software is incorporated into a build system that allows
 * selection among a list of target devices, then similar target
 * devices manufactured by PJRC.COM must be included in the list of
 * target devices and selectable in the same manner.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <Arduino.h>
#include <Audio.h>

#include "MyDsp.h"
#include "pt.h"

#define NUM_PT 2
static struct pt pt[2];


// Teensy 3.x and 4.x  have the LED on pin 13
const int ledPin = LED_BUILTIN;
volatile int ledState = LOW;
volatile unsigned int  TIMER_LED_RED_ON = 0;
volatile unsigned int  TIMER_SINE_ON = 0;
//blink count
volatile unsigned long blink_count = 0; // use volatile for shared variables

IntervalTimer TimerLed;
IntervalTimer TimerSine;
IntervalTimer TimerCount;

MyDsp myDsp;
AudioOutputI2S out;
AudioControlSGTL5000 audioShield;
AudioConnection patchCord0(myDsp,0,out,0);
AudioConnection patchCord1(myDsp,0,out,1);


static PT_THREAD(thread_led_red(struct pt *pt))
{
    PT_BEGIN(pt);

    while(1)
    {
      if (ledState == HIGH)
	ledState = LOW;
      else 
	ledState = HIGH;
      digitalWrite(ledPin, ledState);
      TIMER_LED_RED_ON = 0;
      PT_WAIT_UNTIL(pt, TIMER_LED_RED_ON == 1);
    }

    PT_END(pt);
}

static PT_THREAD(thread_sine(struct pt *pt))
{
    PT_BEGIN(pt);

    while(1)
    {
      TIMER_SINE_ON = 0;
      myDsp.setFreq(random(50,1000));
      PT_WAIT_UNTIL(pt, TIMER_SINE_ON == 1);
    }

    PT_END(pt);
}

void timer_interrupt_led() {
  TIMER_LED_RED_ON = 1;
  //blink countxs
  blink_count++;
}

//blink count
void timer_interrupt_count() {
  Serial.print("number of blink=");
  Serial.println(blink_count);
}

void timer_interrupt_sine() {
  TIMER_SINE_ON = 1;
}



extern "C" int main(void)
{
 
  pinMode(ledPin, OUTPUT);

  //blink count
  Serial.begin(9600);

  AudioMemory(2);
  audioShield.enable();
  audioShield.volume(0.5);
  
  TimerLed.begin(timer_interrupt_led, 500000);  // blinkLED to run every 0.5 seconds
  TimerSine.begin(timer_interrupt_sine, 100000);  // Sine  to run every 0.1 seconds
  TimerCount.begin(timer_interrupt_count, 2000000);  // Count blink every 2 seconds

  PT_INIT(&pt[0]);
  PT_INIT(&pt[1]);

  while (1) {
    thread_led_red(&pt[0]);
    thread_sine(&pt[1]);
  }
  

}

